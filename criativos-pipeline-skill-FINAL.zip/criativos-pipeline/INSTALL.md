# Como instalar a skill `criativos-pipeline`

Estilo "deixa o Claude Code fazer". Você só precisa de **uma chave** (o fal), porque
o Claude usa a sua assinatura pra pensar — não precisa de chave de API da Anthropic.

> **O que faz:** você descreve um produto, o Claude bola as ideias de criativo e
> **corta as fracas antes de gastar**, e só então gera as imagens no fal.ai. Você
> escolhe o modelo de imagem que quiser.

## Parte 1 — Pré-requisitos (com você)
1. **Claude Code** instalado e logado **com sua assinatura** (Pro/Max). Confira: `claude --version`.
2. **Node.js 18+** → `node --version`.
3. **Chave do fal.ai** → crie em https://fal.ai/dashboard/keys
   (É a única chave. Geração de imagem é paga e externa, por isso ela é necessária.)

## Parte 2 — Instalar a skill (o Claude Code faz)
1. Baixe o zip e descompacte → vira a pasta `criativos-pipeline`.
2. No Claude Code, peça:
   > **"instala essa skill pra mim: [caminho]\criativos-pipeline"**
3. Confirme:
   > **"confirma que a skill criativos-pipeline está instalada"**

## Parte 3 — Configurar a chave do fal (Claude prepara, você cola)
1. Peça:
   > **"cria o arquivo .env dessa skill a partir do .env.example e abre pra eu colar minha chave do fal"**
2. **Você** cola a chave do fal (sem aspas) e salva:
   ```
   FAL_KEY=sua-chave-do-fal
   ```
   > Faça no editor — não mande a chave no chat. Guarde como senha.
3. Peça: **"roda o npm install nessa skill"**

## Parte 4 — Usar
1. Reinicie o Claude Code (`/exit` e abra de novo). Confirme com `/skills`.
2. Fale naturalmente:
   > *"cria 5 criativos pro meu tênis de corrida pra iniciantes, formato story, no flux"*

   O Claude bola as ideias, **corta as fracas na hora**, te mostra, pergunta se pode
   gerar, e aí cria as imagens no modelo que você pediu. Tudo salvo em `saida/` com um
   `_contact-sheet.html` pra revisar.

## Escolhendo o modelo
Você fala o nome do modelo (ex.: "flux", "flux pro", "gpt image", "nano banana") e o
Claude resolve. Qualquer modelo de imagem do fal funciona. Se o Claude tiver dúvida do
ID exato de um modelo novo, ele confirma com você.

## Gerar vídeo
O pipeline também gera vídeo. É só pedir, ex.: *"agora transforma esse criativo num
vídeo de 5 segundos"* ou *"cria um vídeo curto desse conceito"*. Funciona de dois
jeitos: animando uma imagem gerada (recomendado) ou direto do texto. Você escolhe o
modelo de vídeo (kling, veo, etc.). **Atenção:** vídeo é cobrado por segundo e custa
bem mais que imagem — o Claude avisa o custo estimado antes de gerar. Pra testar barato,
peça um modelo econômico, poucos segundos e resolução baixa.

## Problemas comuns
| Sintoma | Solução |
|---|---|
| Claude Code pede login/chave | logue com sua assinatura (Pro/Max): `claude login` |
| erro de FAL_KEY | confira a chave no `.env` da skill |
| `/skills` não mostra a skill | reinicie o Claude Code |
| erro ao gerar com um modelo | confirme o ID/parâmetros do modelo no fal.ai |
| sem imagem | confira seu saldo no fal.ai |
