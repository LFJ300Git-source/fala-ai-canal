// scripts/bootstrap-env.js
// Primeiro import do gerar.js. Acha o .env na raiz da skill e carrega.
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { carregarEnv } from "./carregar-env.js";
const aqui = dirname(fileURLToPath(import.meta.url));
carregarEnv(join(aqui, ".."));
if (!process.env.FAL_KEY) {
  console.error("\n[aviso] FAL_KEY nao encontrada. Crie um .env na pasta da skill (veja .env.example).\n");
}
