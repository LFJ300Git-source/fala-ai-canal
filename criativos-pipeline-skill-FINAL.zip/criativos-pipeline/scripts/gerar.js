#!/usr/bin/env node
// scripts/gerar.js
// BRACO EXECUTOR do pipeline (sem API da Anthropic). Imagem E video.
//
// ENTRADA POR ARQUIVO (robusto p/ Windows/PowerShell):
// o Claude escreve um arquivo .json com o pedido e roda:
//   node scripts/gerar.js caminho/para/pedido.json
//
// Isso evita o problema de passar JSON com aspas/chaves pela linha de comando
// (o PowerShell estraçalha). Arquivo funciona igual em qualquer terminal.
//
// REGRA DE OURO (custo): a saida = exatamente o que o usuario pediu.
// 1 saida por conceito. Pediu 1 -> sai 1. Pediu 5 -> saem 5. Sem multiplicar.
//
// Formato do pedido.json:
// {
//   "tipo": "imagem" | "video",            // default "imagem"
//   "modelo": "fal-ai/...",                // ID do fal (aberto, o Claude resolve)
//   "params": { ... },                     // parametros do modelo
//   "conceitos": [                         // a QUANTIDADE aqui = nº de saidas
//     { "rotulo": "...", "angulo": "...", "headline": "...", "prompt": "..." }
//   ],
//   "ref": "caminho/img.png",              // opcional (referencia)
//   "modeloImg": "fal-ai/flux/dev",        // opcional (image-to-video encadeado)
//   "paramsImg": { ... }                   // opcional (params do modelo de imagem)
// }
//
// Precisa so de FAL_KEY no .env.

import "./bootstrap-env.js";
import { fal } from "@fal-ai/client";
import { writeFile, mkdir, readFile } from "node:fs/promises";
import { join, basename } from "node:path";

fal.config({ credentials: process.env.FAL_KEY });

function fail(msg) { console.error("\nErro:", msg); process.exit(1); }

async function carregarPedido() {
  const caminho = process.argv[2];
  if (!caminho) fail("uso: node scripts/gerar.js <pedido.json>");
  let texto;
  try { texto = await readFile(caminho, "utf8"); }
  catch { fail(`nao consegui ler o arquivo de pedido: ${caminho}`); }
  let p;
  try { p = JSON.parse(texto); }
  catch (e) { fail(`pedido.json nao e JSON valido: ${e.message}`); }
  // defaults e validacao
  p.tipo = p.tipo || "imagem";
  p.params = p.params || {};
  p.paramsImg = p.paramsImg || {};
  p.conceitos = p.conceitos || [];
  if (!p.modelo) fail("falta 'modelo' no pedido (ID do fal)");
  if (!p.conceitos.length) fail("falta 'conceitos' no pedido (lista de aprovados)");
  return p;
}

async function subirArquivo(caminhoLocal) {
  const bytes = await readFile(caminhoLocal);
  return await fal.storage.upload(new File([bytes], basename(caminhoLocal)));
}

function extrairUrls(data) {
  if (!data) return [];
  if (data.video?.url) return [data.video.url];
  if (Array.isArray(data.videos)) return data.videos.map(v => v.url || v);
  if (Array.isArray(data.images)) return data.images.map(i => i.url || i);
  if (data.image?.url) return [data.image.url];
  return [];
}

async function baixar(url, caminho) {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`download falhou: ${resp.status}`);
  await writeFile(caminho, Buffer.from(await resp.arrayBuffer()));
}

// Gera UMA saida (imagem ou video) para UM conceito. 1 por conceito.
async function gerarItem({ tipo, modelo, inputBase, prompt, rotulo, pasta, refUrl }) {
  const input = { ...inputBase, prompt };
  if (tipo === "imagem") input.num_images = 1; // 1 por conceito, sempre
  if (refUrl) {
    const campo = inputBase._refField || "image_url";
    input[campo] = refUrl;
  }
  delete input._refField;

  const r = await fal.subscribe(modelo, { input, logs: false });
  const urls = extrairUrls(r.data);
  if (!urls.length) throw new Error("fal nao retornou saida");

  await mkdir(pasta, { recursive: true });
  const ext = tipo === "video" ? "mp4" : "png";
  const caminho = join(pasta, `${rotulo}.${ext}`);
  await baixar(urls[0], caminho); // só a primeira saida — 1 por conceito
  return caminho;
}

async function contactSheet(itens, pasta) {
  const cards = itens.map((it) => {
    const arq = basename(it.arquivo);
    const midia = arq.endsWith(".mp4")
      ? `<video src="${arq}" controls style="width:100%;border-radius:8px"></video>`
      : `<img src="${arq}" style="width:100%;border-radius:8px"/>`;
    return `<figure style="margin:0">
  ${midia}
  <figcaption style="font:13px sans-serif;margin-top:6px">
    <strong>${it.rotulo}</strong> &middot; ${it.angulo || ""}<br/>${it.headline || ""}
  </figcaption></figure>`;
  }).join("\n");
  const html = `<!doctype html><meta charset="utf-8">
<body style="background:#111;color:#eee;padding:24px">
<h1 style="font:600 20px sans-serif">Contact sheet</h1>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px">
${cards}</div></body>`;
  const caminho = join(pasta, "_contact-sheet.html");
  await writeFile(caminho, html);
  return caminho;
}

async function main() {
  const p = await carregarPedido();
  if (!process.env.FAL_KEY) fail("FAL_KEY ausente — configure no .env");

  const pasta = `./saida/${Date.now()}`;
  let refUrlGlobal = null;
  if (p.ref) { console.log(`Subindo referencia: ${p.ref}`); refUrlGlobal = await subirArquivo(p.ref); }

  const encadeado = p.tipo === "video" && p.modeloImg;
  console.log(`\nTipo: ${p.tipo}${encadeado ? " (imagem->video encadeado)" : ""}`);
  console.log(`Modelo: ${p.modelo} | saidas: ${p.conceitos.length} (1 por conceito)\n`);

  const itens = [];
  for (const c of p.conceitos) {
    try {
      let refParaVideo = refUrlGlobal;
      if (encadeado) {
        console.log(`  [${c.rotulo}] gerando frame inicial...`);
        const rImg = await fal.subscribe(p.modeloImg, {
          input: { ...p.paramsImg, prompt: c.prompt, num_images: 1 }, logs: false,
        });
        const imgUrls = extrairUrls(rImg.data);
        if (!imgUrls.length) throw new Error("modelo de imagem nao retornou frame");
        refParaVideo = imgUrls[0];
      }
      const arquivo = await gerarItem({
        tipo: p.tipo, modelo: p.modelo, inputBase: { ...p.params },
        prompt: c.prompt, rotulo: c.rotulo, pasta, refUrl: refParaVideo,
      });
      itens.push({ ...c, arquivo });
      console.log(`  gerado: ${arquivo}`);
    } catch (e) {
      console.log(`  ERRO em ${c.rotulo}: ${e.message}`);
    }
  }

  const sheet = await contactSheet(itens, pasta);
  console.log(`\nContact sheet: ${sheet}`);
  console.log(`Feito. ${itens.length} ${p.tipo === "video" ? "videos" : "imagens"} em ${pasta}\n`);
}
main().catch((e) => fail(e.message));
