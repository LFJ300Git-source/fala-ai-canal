// scripts/carregar-env.js
// Carrega variaveis de um .env (se existir) para process.env. Node nativo (>=20.12/22).
import { existsSync } from "node:fs";
import { join } from "node:path";
export function carregarEnv(dir = process.cwd()) {
  const caminho = join(dir, ".env");
  if (!existsSync(caminho)) return false;
  const jaSetadas = {};
  for (const k of ["FAL_KEY"]) if (process.env[k]) jaSetadas[k] = process.env[k];
  process.loadEnvFile(caminho);
  for (const [k, v] of Object.entries(jaSetadas)) process.env[k] = v;
  return true;
}
