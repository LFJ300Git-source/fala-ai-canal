---
name: criativos-pipeline
description: Cria criativos visuais (imagens E vídeos) para anúncios a partir de um briefing de produto. Você (Claude) gera as ideias de criativo e corta as fracas ANTES de gerar, economizando crédito; depois gera as imagens ou vídeos aprovados via fal.ai. O usuário escolhe livremente qualquer modelo de imagem ou vídeo do fal. Use sempre que o usuário pedir para criar criativos, anúncios, variações de imagem ou vídeo para tráfego pago, animar um criativo, ou gerar material de marketing de um produto — mesmo sem dizer a palavra "pipeline".
---

# Pipeline de criativos (sem API da Anthropic)

Cria criativos (imagens ou vídeos) para anúncios. A inteligência (gerar conceitos e
filtrar) é feita por VOCÊ, Claude, aqui na conversa — usando a assinatura do usuário,
sem chave de API da Anthropic. A geração é feita por um script que chama o fal.ai.

**A ideia que vende:** economizar crédito. Você bola as ideias e corta as fracas de
graça (é só raciocínio). Só as aprovadas viram imagem/vídeo pago no fal.

**Modelo aberto:** o usuário usa qualquer modelo de imagem OU vídeo do fal. Você
resolve o ID e os parâmetros.

## REGRA DE OURO — QUANTIDADE (controle de custo)
A saída = exatamente o que o usuário pediu. 1 saída por conceito. Pediu 1 → sai 1.
Pediu 5 → saem 5. NUNCA gere a mais "pra garantir", especialmente vídeo (caro).
Se o filtro cortar e sobrar menos que o pedido, gere mais conceitos até ter, entre os
aprovados, o número que o usuário pediu.

## COMO RODAR O SCRIPT (importante — entrada por ARQUIVO)
NÃO passe JSON pela linha de comando (o PowerShell do Windows estraçalha aspas/chaves).
Em vez disso: CRIE um arquivo `pedido.json` e rode o script apontando pra ele.

IMPORTANTE — como criar o arquivo (evita erro de shell):
Use sua ferramenta de ESCRITA DE ARQUIVO (write/create file) para criar o `pedido.json`,
ou crie via Node. NÃO use comandos de leitura/escrita específicos de um shell (NÃO use
`Get-Content`, `Set-Content`, `cat`, `echo >` etc.) — eles falham quando o shell ativo
é diferente (ex.: `Get-Content` é do PowerShell e quebra no Bash com "command not
found"). A forma neutra e confiável, se precisar usar o terminal, é via Node:
```bash
node -e "require('fs').writeFileSync('pedido.json', JSON.stringify(PEDIDO))"
```
Mas o mais simples é escrever o arquivo direto com a ferramenta de criação de arquivo.

1. Crie o `pedido.json` na pasta da skill com este formato:
```json
{
  "tipo": "imagem",
  "modelo": "fal-ai/flux/dev",
  "params": { "image_size": "portrait_16_9" },
  "conceitos": [
    { "rotulo": "dor-pe", "angulo": "dor", "headline": "...", "prompt": "..." },
    { "rotulo": "leveza", "angulo": "desejo", "headline": "...", "prompt": "..." }
  ]
}
```
2. Rode (simples, sem JSON solto no terminal):
```bash
node scripts/gerar.js pedido.json
```

A QUANTIDADE de saídas = nº de itens em "conceitos". 2 conceitos = 2 imagens.

## Quando usar
Pedidos de criar criativos, anúncios, imagens/vídeos de marketing, animar criativo.

## Pré-requisitos
1. Node.js (`node --version`).
2. `npm install` na pasta da skill (instala o cliente do fal).
3. `.env` da skill com `FAL_KEY` (fal.ai/dashboard/keys). Há `.env.example`.
   NÃO é necessária chave da Anthropic — você roda na assinatura do usuário.

## O passo a passo que VOCÊ (Claude) executa

### 1) Gerar os conceitos (você faz, de graça)
Crie a quantidade que o usuário pediu, cada um com ângulo diferente (dor, desejo,
prova social, urgência, curiosidade). Cada conceito: `rotulo`, `angulo`, `headline`,
`prompt` (em inglês, descritivo, pronto pro modelo).

### 2) Filtrar (você faz, de graça) — O DIFERENCIAL
Seja EXIGENTE, corte os fracos com motivo. Mostre claramente:
  [OK ] dor-pe-cansado — ângulo de dor claro, visual forte
  [CUT] milhares-comecaram — prova social genérica, desperdiçaria crédito
Se cortar e ficar abaixo do pedido, gere novos até ter o número pedido de aprovados.

### 3) Aprovação (pergunte ao usuário)
Liste os aprovados e PERGUNTE se pode gerar. Para VÍDEO, informe o custo estimado antes.
Não gere nada antes do "sim".

### 4) Resolver modelo + parâmetros (você faz)
- MODELO: converta o nome dito no ID do fal e RESOLVA SOZINHO — não pergunte o ID ao
  usuário. Se tiver dúvida do ID exato, descubra (verifique no fal) em vez de perguntar.
  Só pare pra perguntar se, após tentar, realmente não conseguir identificar o modelo.
  Imagem (ex.): "flux"→`fal-ai/flux/dev`, "flux pro"→`fal-ai/flux-pro/v1.1-ultra`,
  "gpt image"→`fal-ai/gpt-image-2`, "nano banana pro"→`fal-ai/nano-banana-pro`.
- PARÂMETROS: só campos que AQUELE modelo aceita. Formato: story/9:16, quadrado/1:1,
  paisagem/16:9 (image_size: portrait_16_9/square_hd/landscape_16_9; ou aspect_ratio).
  Referência: ponha `"_refField": "image_url"` em params e use "ref" no pedido.

### 5) Gerar (escreva o pedido.json e rode)
Escreva o `pedido.json` (passo acima) com os conceitos APROVADOS e rode
`node scripts/gerar.js pedido.json`. O script gera 1 saída por conceito, baixa e salva
em `saida/<timestamp>/` com `_contact-sheet.html`.

## Gerando VÍDEO

Mesmo fluxo, mas no pedido.json use `"tipo": "video"`. Vídeo é cobrado POR SEGUNDO e
custa MUITO mais que imagem (~US$0,07 a ~US$0,50+/seg). SEMPRE confirme o custo antes.
Quantidade: nº de conceitos = nº de vídeos. Para 1 vídeo, 1 conceito.

**Texto vira vídeo:** `"tipo":"video"`, `"modelo":"ID_VIDEO"`, `"params":{...}`.

**Imagem vira vídeo (encadeado, recomendado):** adicione no pedido.json:
```json
{
  "tipo": "video",
  "modelo": "ID_IMAGE_TO_VIDEO",
  "params": { "duration": 5 },
  "modeloImg": "fal-ai/flux/dev",
  "paramsImg": { "image_size": "portrait_16_9" },
  "conceitos": [ { "rotulo": "...", "prompt": "..." } ]
}
```
O script gera a imagem, e a usa como frame inicial do vídeo.

Parâmetros de vídeo: `duration` (segundos), resolução, `audio`. Cada modelo tem os
seus; verifique no fal se incerto. Para demo barata: modelo econômico, poucos segundos,
resolução baixa. Resolva o ID do modelo de vídeo SOZINHO, sem perguntar ao usuário — se
tiver dúvida, descubra. Mas SEMPRE avise o modelo escolhido e o custo estimado ANTES de
gerar (o usuário não precisa confirmar o ID, só fica ciente do custo).

O contact sheet mostra vídeos com player embutido e imagens normais.

## Regras importantes
- NUNCA gere antes da aprovação (passo 3).
- QUANTIDADE = o que o usuário pediu. Nunca a mais. Vídeo: avise o custo antes.
- MODELO: resolva o ID SOZINHO, sem perguntar ao usuário. Para vídeo, avise o custo
  estimado antes de gerar (mas não pergunte qual ID usar).
- SEMPRE entrada por arquivo (pedido.json), nunca JSON pela linha de comando.
- Para criar o pedido.json, use a ferramenta de escrita de arquivo ou Node — NUNCA
  comandos de shell específicos (Get-Content/Set-Content/cat/echo), que quebram quando
  o shell ativo é outro.
- Passos 1 e 2 são você, na conversa (sem API da Anthropic).
- Se faltar FAL_KEY, avise antes de gerar.

## Arquivos
- `scripts/gerar.js` — executor: lê o pedido.json, gera no fal (1 por conceito)
- `scripts/bootstrap-env.js` / `carregar-env.js` — carregam o .env (só FAL_KEY)
- `package.json` — dependência (só o cliente do fal)
